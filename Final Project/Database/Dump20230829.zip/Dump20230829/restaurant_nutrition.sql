-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurant
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nutrition`
--

DROP TABLE IF EXISTS `nutrition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nutrition` (
  `nutId` int NOT NULL AUTO_INCREMENT,
  `dishId` int NOT NULL,
  `nutrition` varchar(45) NOT NULL,
  `value` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`nutId`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nutrition`
--

LOCK TABLES `nutrition` WRITE;
/*!40000 ALTER TABLE `nutrition` DISABLE KEYS */;
INSERT INTO `nutrition` VALUES (1,1,'Calories',220),(2,1,'Total Fat',11),(3,1,'Saturated Fat',2),(4,1,'Cholesterol',37),(5,1,'Sodium',120),(6,1,'Potassium',33),(7,1,'Total Carbohydrate',22),(8,1,'Sugar',8),(9,1,'Protein',8),(10,1,'Dietary Fiber',2),(11,2,'Calories',250),(12,2,'Total Fat',8),(13,2,'Saturated Fat',2),(14,2,'Cholesterol',25),(15,2,'Sodium',500),(16,2,'Potassium',50),(17,2,'Total Carbohydrate',30),(18,2,'Sugar',5),(19,2,'Protein',10),(20,2,'Dietary Fiber',2),(21,3,'Calories',151),(22,3,'Total Fat',6),(23,3,'Saturated Fat',1),(24,3,'Cholesterol',20),(25,3,'Sodium',110),(26,3,'Potassium',31),(27,3,'Total Carbohydrate',20),(28,3,'Sugar',3),(29,3,'Protein',7),(30,3,'Dietary Fiber',1),(31,4,'Calories',260),(32,4,'Total Fat',9),(33,4,'Saturated Fat',3),(34,4,'Cholesterol',30),(35,4,'Sodium',520),(36,4,'Potassium',55),(37,4,'Total Carbohydrate',32),(38,4,'Sugar',6),(39,4,'Protein',11),(40,4,'Dietary Fiber',3),(41,5,'Calories',280),(42,5,'Total Fat',11),(43,5,'Saturated Fat',3),(44,5,'Cholesterol',40),(45,5,'Sodium',530),(46,5,'Potassium',60),(47,5,'Total Carbohydrate',34),(48,5,'Sugar',7),(49,5,'Protein',12),(50,5,'Dietary Fiber',3),(51,6,'Calories',231),(52,6,'Total Fat',9),(53,6,'Saturated Fat',2),(54,6,'Cholesterol',25),(55,6,'Sodium',210),(56,6,'Potassium',41),(57,6,'Total Carbohydrate',28),(58,6,'Sugar',4),(59,6,'Protein',8),(60,6,'Dietary Fiber',2),(61,7,'Calories',250),(62,7,'Total Fat',10),(63,7,'Saturated Fat',2),(64,7,'Cholesterol',31),(65,7,'Sodium',521),(66,7,'Potassium',56),(67,7,'Total Carbohydrate',31),(68,7,'Sugars',6),(69,7,'Protein',11),(70,7,'Dietary Fiber',3),(71,8,'Calories',240),(72,8,'Total Fat',9),(73,8,'Saturated Fat',2),(74,8,'Cholesterol',29),(75,8,'Sodium',511),(76,8,'Potassium',51),(77,8,'Total Carbohydrate',30),(78,8,'Sugars',5),(79,8,'Protein',10),(80,8,'Dietary Fiber',2),(81,9,'Calories',260),(82,9,'Total Fat',10),(83,9,'Saturated Fat',3),(84,9,'Cholesterol',32),(85,9,'Sodium',530),(86,9,'Potassium',58),(87,9,'Total Carbohydrate',31),(88,9,'Sugars',5),(89,9,'Protein',11),(90,9,'Dietary Fiber',3),(91,10,'Calories',240),(92,10,'Total Fat',10),(93,10,'Saturated Fat',3),(94,10,'Cholesterol',35),(95,10,'Sodium',510),(96,10,'Potassium',50),(97,10,'Total Carbohydrate',30),(98,10,'Sugars',6),(99,10,'Protein',9),(100,10,'Dietary Fiber',2),(101,11,'Calories',100),(102,11,'Total Fat',2),(103,11,'Saturated Fat',1),(104,11,'Cholesterol',5),(105,11,'Sodium',10),(106,11,'Potassium',20),(107,11,'Total Carbohydrate',20),(108,11,'Sugars',10),(109,11,'Protein',2),(110,11,'Dietary Fiber',1),(111,12,'Calories',120),(112,12,'Total Fat',3),(113,12,'Saturated Fat',1),(114,12,'Cholesterol',10),(115,12,'Sodium',15),(116,12,'Potassium',25),(117,12,'Total Carbohydrate',25),(118,12,'Sugars',15),(119,12,'Protein',3),(120,12,'Dietary Fiber',1);
/*!40000 ALTER TABLE `nutrition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-29 22:17:37
