-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurant
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dish`
--

DROP TABLE IF EXISTS `dish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dish` (
  `dishId` int NOT NULL AUTO_INCREMENT,
  `dishName` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `price` decimal(5,2) NOT NULL,
  `ingredients` varchar(100) DEFAULT NULL,
  `catId` int NOT NULL,
  `dishImageURL` varchar(255) DEFAULT NULL,
  `preprationTime` int DEFAULT NULL,
  `cookingTime` int DEFAULT NULL,
  `servings` int DEFAULT NULL,
  PRIMARY KEY (`dishId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish`
--

LOCK TABLES `dish` WRITE;
/*!40000 ALTER TABLE `dish` DISABLE KEYS */;
INSERT INTO `dish` VALUES (1,'Phở','A Vietnamese noodle soup consisting of broth, rice noodles, and meat, primarily beef or chicken.',10.99,'Rice noodles, beef slices, onions, ginger, beef bone broth',1,'/images/products/pho.jpg',60,120,1),(2,'Bánh Mì','A Vietnamese sandwich that consists of a French baguette filled with a variety of ingredients.',5.99,'Baguette, pork, pickled vegetables, pâté, cilantro, chili',1,'/images/products/banhmi.jpg',10,30,1),(3,'Gỏi Cuốn','Vietnamese spring roll or cold roll; translucent rice paper rolled around greens, coriander, minced pork, shrimp, or crab.',7.99,'Rice paper, shrimp, herbs, pork, rice vermicelli',3,'/images/products/goi_cuon.jpg',10,30,3),(4,'Bún Thịt Nướng','A popular Vietnamese dish made with grilled pork, vermicelli noodles, and herbs.',8.99,'Vermicelli noodles, grilled pork, peanuts, shallots, fried onions',2,'/images/products/bun_thit_nuong.jpg',20,20,3),(5,'Cà Ri Gà','Vietnamese chicken curry made with succulent chicken pieces, potatoes and carrots.',9.99,'Chicken, potatoes, carrots, coconut milk, lemongrass, curry powder',2,'/images/products/cari_ga.jpg',20,40,4),(6,'Bánh Xèo','Crispy Vietnamese pancake made with rice flour, turmeric, shrimp, and bean sprouts.',6.99,'Rice flour, turmeric, shrimp, bean sprouts, onions',3,'/images/products/banh_xeo.jpg',20,10,2),(7,'Bún Riêu','A Vietnamese meat rice vermicelli soup with crab and tomato.',9.49,'Vermicelli, crab, tomatoes, tofu, fried shallots',2,'/images/products/bun_rieu.jpg',20,60,1),(8,'Bánh Canh','Thick Vietnamese noodle soup made with tapioca flour or a mixture of rice and tapioca flour.',8.49,'Tapioca noodles, shrimp, crab, pork, fried shallots',1,'/images/products/banh_canh_cua.png',30,60,2),(9,'Hủ Tiếu','A noodle soup with a pork stock and seafood.',9.99,'Rice noodles, pork, shrimp, garlic, bone broth',1,'/images/products/hu_tieu.jpg',20,60,3),(10,'Chả Giò','Vietnamese fried spring roll made with ground meat and wrapped in rice paper.',5.49,'Ground pork, shrimp, mushrooms, rice paper, vermicelli',3,'/images/products/cha_gio.webp',5,10,4),(11,'Cafe sua nong','Vietnamese hot coffee.',4.99,'Coffee, weetened condensed milk',4,'/images/products/cafe_nong.jpg',10,0,1),(12,'Cafe sua da','Vietnamese iced coffee.',4.99,'Coffee, sweetened condensed milk, ice',4,'/images/products/cafe_sua_da.jpg',10,0,1),(13,'Iced tamarind drink','Tamarind drink is a popular drink prepared from the tamarind wet pulp blocks with water and sugar.',4.99,'Tamarind, sugar, ginger, peanut',4,'/images/products/da_me.jpg',10,0,1),(14,'Nước Mía','Sugar Cane Juice',3.99,'Sugar cane, calamansi',4,'/images/products/nuoc_mia.webp',5,0,1),(15,'Banh Da Lon','Banh Da Lon is a Vietnamese steamed layered cake that is infused with pandan leaves, coconut milk',4.99,'Rice flour, coconut milk, sugar, pandan leaves',5,'/images/products/dessert/banh_da_lon.webp',10,20,2),(16,'Khoai Mi Nuoc Cot Dua',' It’s a rich Vietnamese dessert made with chunks of boiled cassava served in a creamy coconut sauce.',4.99,'Cassava, coconut milk, roasted peanut',5,'/images/products/dessert/che_khoai_mi.webp',10,5,1),(17,'Che bap','Vietnamese sweet corn, tapioca and coconut milk',3.99,'Sweet corn, tapioca, coconut milk',5,'/images/products/dessert/che_bap.jpg',15,5,1);
/*!40000 ALTER TABLE `dish` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-29 22:17:38
