-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: restaurant
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `ordId` int NOT NULL AUTO_INCREMENT,
  `ordDate` datetime NOT NULL,
  `ordName` varchar(45) NOT NULL,
  `ordAddress` varchar(100) NOT NULL,
  `ordPhone` varchar(15) NOT NULL,
  `ordEmail` varchar(45) DEFAULT NULL,
  `totalPrice` decimal(6,2) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'New',
  PRIMARY KEY (`ordId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'2023-08-13 22:07:49','But','1000 N 4th street','12345698','butbuiapp@gmail.com',96.88,'New'),(2,'2023-08-15 03:41:55','ssss','1000 N 4th street','12345698','butbuiapp@gmail.com',20.97,'New'),(3,'2023-08-15 03:43:37','xx','1000 N 4th street','12345698','butbuiapp@gmail.com',7.99,'New'),(4,'2023-08-15 19:41:11','ssss','1000 N 4th street','12345698','butbuiapp@gmail.com',5.99,'New'),(5,'2023-08-15 19:55:24','ssss','1000 N 4th street','12345698','butbuiapp@gmail.com',5.99,'New'),(6,'2023-08-15 20:19:44','ssss','1000 N 4th street','12345698','butbuiapp@gmail.com',5.99,'New'),(7,'2023-08-16 17:21:15','ssss','1000 N 4th street','12345698','butbuidev@gmail.com',21.96,'New'),(8,'2023-08-16 17:23:07','ssss','1000 N 4th street','12345698','butbuidev@gmail.com',21.96,'New'),(9,'2023-08-16 17:24:00','aaaa','1000 N 4th street','12345698','butbuidev@gmail.com',20.98,'New'),(10,'2023-08-16 17:25:51','sdg','1000 N 4th street','12345698','butbuidev@gmail.com',9.99,'New'),(11,'2023-08-16 19:03:00','ssss','1000 N 4th street','12345698','butbuidev@gmail.com',5.99,'New'),(12,'2023-08-16 21:46:15','ssss','1000 N 4th street','12345698','butbuidev@gmail.com',37.94,'New'),(13,'2023-08-17 13:17:00','1234567890 1234567890 1234567890 1234567890 1','1000 N 4th street 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 12345','111111111111111','1234567890@1234567890.1234567890123456789012',7.99,'New'),(14,'2023-08-17 15:19:24','Huan','1000 N 4th street','111111111111111','butbuidev@gmail.com',54.95,'New');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-29 22:17:38
